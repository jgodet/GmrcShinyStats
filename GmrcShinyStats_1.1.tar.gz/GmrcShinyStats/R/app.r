# app.r
# written by JuG
# August 01 2019


#' Do something
#' @author JuG
#' @description
#' @param
#' @details
#' @examples
#'
#'
#' @return
#' @export



app<- function(){
  if(!require('shiny')){install.packages('shiny')}
  require(shiny)
  if(!require('shinyFiles')){install.packages('shinyFiles')}
  require(shinyFiles)
 shinyApp(ui, server)
}

