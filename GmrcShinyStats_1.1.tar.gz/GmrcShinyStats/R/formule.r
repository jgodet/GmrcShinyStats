# formule.r
# written by JuG
# August 05 2019


#' Do something
#' @author JuG
#' @description
#' @param
#' @details
#' @examples
#'
#'
#' @return
#' @export


formule<- function(x){

  return(as.formula(paste("~", x)))
}
